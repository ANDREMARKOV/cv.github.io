from django.contrib import admin

# Register your models here.
from clients.models import Clients

admin.site.register(Clients)